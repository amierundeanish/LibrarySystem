

<?php $__env->startSection('title', 'Books'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3">Books</h1>
  <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Add New Book</a>
</div>

<table class="table table-striped table-bordered">
  <thead>
    <tr>
      <th>#</th>
      <th>Title</th>
      <th>Author</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><?php echo e($book->id); ?></td>
        <td><?php echo e($book->title); ?></td>
        <td><?php echo e($book->author); ?></td>
        <td><?php echo e($book->year_published); ?></td>
        <td><?php echo e($book->genre); ?></td>
        <td>
          <a href="<?php echo e(route('books.edit', $book)); ?>" class="btn btn-sm btn-warning">Edit</a>

          <form action="<?php echo e(route('books.destroy', $book)); ?>" method="POST" class="d-inline"
                onsubmit="return confirm('Are you sure you want to delete this book?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-danger">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>
        <td colspan="6" class="text-center">No books found.</td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LibrarySystem\resources\views/books/index.blade.php ENDPATH**/ ?>